﻿#pragma once

uint16_t _crc16_update(uint16_t crc, uint8_t data);
